# Project 2: Shiny App Development Version 2.0

### Doc folder

The doc directory contains the report or presentation files. It can have subfolders.  

house_processing.rmd is used to process the data of house price in NY.

