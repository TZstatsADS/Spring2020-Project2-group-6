# Project 2: Shiny App Development Version 2.0

### Code lib Folder

The lib directory contains various files with function definitions (but only function definitions - no code that actually runs).

