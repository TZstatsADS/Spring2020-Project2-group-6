# Project 2: Shiny App Development Version 2.0

### Output folder

The output directory contains analysis output, processed datasets, logs, or other processed things.

house1 is the raw data of house price.
house_processed is the processed data of house price.